<?php include('header.php'); ?>
<div class="heaven-bakery-section">
  <div class="heaven-deals">
    <div class="container">
      <h3>Best Combos </h3>
      <h2>Deals for a Meal?</h2>
      <div class="container">
        <div class="american-biscotta imgtb60">
          <div class="row align-items-center h-100">      
            <div class="col-lg-6 col-sm-6">
              <h4>. DINE IN DEAL .</h4>
               <h1>Americano Biscatto</h1>
               <p>Our finest blend of coffee served with <br/>2 freshly backed chocolate chip cookies.</p>
               <h5>$12 - Available from 9am-12pm</h5>
            </div>
            <div class="col-lg-6 col-sm-6">
              <img src="images/heaven-biscatto.png" class="img-fluid">
            </div>
          </div>
        </div>
      </div>
      <div class="container">
        <div class="american-biscotta imgtb60 american-trycookies">
          <div class="row align-items-center h-100">      
            <div class="col-lg-6 col-sm-6">
              <h4>. DINE IN DEAL .</h4>
               <h1>Trio  Cookie <br/>Combo</h1>
               <p>Choose any three flavours of<br/>cookies one pound each</p>
               <h5>$30 - Available from 9am -  9pm</h5>
            </div>
            <div class="col-lg-6 col-sm-6">
              <img src="images/heaven-cookies.jpg" class="img-fluid">
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>




<?php include('footer.php'); ?>