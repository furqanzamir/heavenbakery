<div class="heaven-bakery-section">
	<div class="getintouch">
	  <div class="container">  
	         <h3>Talk To Us</h3>
	         <h2>Get in touch for details and inquiry.</h2>
	         <p>We are quick to respond and always here to help you out.</p>
	         <a href="#" class="btn btnprim">CONTACT US</a>
	  </div>
	</div>
</div>
