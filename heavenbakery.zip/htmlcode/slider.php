<div class="heaven-slider">
  <div class="owl-carousel owl-theme">
      <div class="item"><img src="images/heaven-slider.png" class="img-fluid"></div>
      <div class="item"><img src="images/heaven-slider.png" class="img-fluid"></div>
      <div class="item"><img src="images/heaven-slider.png" class="img-fluid"></div>
      <div class="item"><img src="images/heaven-slider.png" class="img-fluid"></div>
  </div>
  <a href="#" class="pagearrow"><i class="fa fa-angle-down" aria-hidden="true"></i></a>
</div>
