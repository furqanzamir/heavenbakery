
<footer>
	<div class="container">
		<div class="row">
			<div class="col-lg-6 col-sm-6">
				<div class="footer-link">
					<ul>
						<li><a href="#">SHOP</a></li>
						<li><a href="#">OUTLET</a></li>
						<li><a href="#">CUSTOM CAKES</a></li>
						<li><a href="#">DEALS</a></li>
						<li><a href="#">ABOUT</a></li>
						<li><a href="#">CONTACT</a></li>
					</ul>
				</div>
			</div>
			<div class="col-lg-6 col-sm-6">
				<div class="footer-socail-link">
					<ul>
						<li><p><a href="#">Austin, TX, United States, +1 512-491-8456</a></p></li>
						<li><a href="#"> FACEBOOK</a></li>
						<li><a href="#"> INSTAGRAM</a></li>
						<li><a href="#"> PINTREST</a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</footer>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script type="text/javascript" src="js/jquery-3.3.1.slim.min.js"></script>
    <script type="text/javascript" src="js/popper.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/owl.carousel.min.js"></script>
    <script type="text/javascript" src="js/custom.js"></script>
  </body>
</html>