<?php
/**
 * Email Footer
 *
 * @author 		RestroPress
 * @package 	RestroPress/Templates/Emails
 * @version     2.1
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// This is the footer used if no others are available

?>
    </body>
</html>